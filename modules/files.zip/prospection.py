import streamlit as st
import pandas as pd
from database import get_db
from utils import fmt_date, fmt_money
from datetime import date, timedelta
import re

ETAPES = [
    "Nouveau prospect", "Contacté", "Intéressé", "Réunion planifiée",
    "Proposition envoyée", "Négociation", "Recontacter plus tard",
    "Refusé", "Converti",
]
ETAPE_STYLE = {
    "Nouveau prospect":      ("🆕", "#E6F1FB", "#185FA5"),
    "Contacté":              ("📧", "#F0F4FF", "#2E86DE"),
    "Intéressé":             ("👀", "#FAEEDA", "#854F0B"),
    "Réunion planifiée":     ("📅", "#FFF4E6", "#C05C00"),
    "Proposition envoyée":   ("📄", "#E8F4FD", "#1A6EA5"),
    "Négociation":           ("🤝", "#F5E6FF", "#6B2FA0"),
    "Recontacter plus tard": ("🔄", "#F1EFE8", "#5F5E5A"),
    "Refusé":                ("❌", "#FCEBEB", "#A32D2D"),
    "Converti":              ("✅", "#EAF3DE", "#3B6D11"),
}
TYPES_PROSPECT = ["Importateur / client", "Producteur à représenter"]


def _ensure_tables(db):
    db.execute("""CREATE TABLE IF NOT EXISTS prospection (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        civilite TEXT DEFAULT '—', prenom TEXT, nom TEXT NOT NULL,
        type TEXT DEFAULT 'Importateur / client',
        pays TEXT, activite TEXT, source TEXT,
        etape TEXT DEFAULT 'Nouveau prospect',
        contact_nom TEXT, contact_email TEXT, contact_mobile TEXT,
        contact_tel_fixe TEXT, contact_poste TEXT,
        contact_whatsapp TEXT, contact_langue TEXT, contact_role_email TEXT,
        producteur_interet TEXT, date_prochain_contact TEXT,
        raison_refus TEXT, notes TEXT, adresse TEXT,
        tel_fixe_societe TEXT, concurrents TEXT, date_fiche_source TEXT,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        archived INTEGER DEFAULT 0
    )""")
    db.execute("""CREATE TABLE IF NOT EXISTS prospection_interactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        prospect_id INTEGER REFERENCES prospection(id),
        date_interaction TEXT DEFAULT (datetime('now')),
        type TEXT, contenu TEXT, notes TEXT
    )""")
    db.commit()
    for col, defn in [
        ("source","TEXT"), ("contact_tel_fixe","TEXT"), ("contact_poste","TEXT"),
        ("contact_whatsapp","TEXT"), ("contact_langue","TEXT"),
        ("contact_role_email","TEXT"), ("adresse","TEXT"),
        ("tel_fixe_societe","TEXT"), ("concurrents","TEXT"),
        ("date_fiche_source","TEXT"), ("civilite","TEXT DEFAULT '—'"),
        ("prenom","TEXT"), ("activite","TEXT"),
    ]:
        try:
            db.execute(f"ALTER TABLE prospection ADD COLUMN {col} {defn}")
            db.commit()
        except Exception:
            pass


def generer_email_prospection(prospect_nom, pays, contact_prenom,
                               producteurs_selectionnes, langue, ton):
    import anthropic
    prods_str = ", ".join(producteurs_selectionnes) if producteurs_selectionnes else "notre portefeuille"
    prompt = f"""You are Gautier Salinier, founder of Angels' Share Marketing Limited,
a boutique wine & spirits agency representing exceptional French producers in Asia.

Write a FIRST CONTACT prospecting email to {prospect_nom} ({pays}),
contact: {contact_prenom or 'the buyer'}.
Producers to present: {prods_str}
Tone: {ton} | Language: {langue}
Style: human, warm, passionate — NOT a template.
Length: 150-200 words max.
Include subject line as "Subject: ..."
NO signature block.
Output ONLY the email text."""
    client = anthropic.Anthropic()
    response = client.messages.create(
        model="claude-sonnet-4-20250514", max_tokens=600,
        messages=[{"role": "user", "content": prompt}]
    )
    return response.content[0].text


def render():
    st.markdown("## 🔍 Prospection")
    db = get_db()
    _ensure_tables(db)

    pays_list = [p["nom"] for p in db.execute(
        "SELECT nom FROM pays WHERE actif=1 ORDER BY nom").fetchall()]
    producteurs_list = [p["nom"] for p in db.execute(
        "SELECT nom FROM producteurs WHERE archived=0 ORDER BY nom").fetchall()]

    tab1, tab2, tab3, tab4 = st.tabs([
        "📨 Campagne email", "🗂️ Pipeline", "➕ Nouveau prospect", "📊 Statistiques"
    ])

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 1 — CAMPAGNE EMAIL
    # ══════════════════════════════════════════════════════════════════════════
    with tab1:
        st.markdown("### 📨 Campagne de prospection")

        # ── Filtres ───────────────────────────────────────────────────────────
        st.markdown("#### 1. Filtrer les prospects")
        fc1, fc2, fc3 = st.columns(3)
        sel_pays   = fc1.selectbox("🌍 Pays", ["— Tous —"] + pays_list, key="camp_pays_sel")
        sel_etape  = fc2.selectbox("Étape", ["— Toutes —"] + ETAPES, key="camp_etape_sel")
        sel_source = fc3.text_input("Source", placeholder="ex: Business France…", key="camp_src_sel")

        # ── Charger les prospects selon les filtres courants ──────────────────
        q = "SELECT * FROM prospection WHERE archived=0"
        params = []
        if sel_pays != "— Tous —":
            q += " AND pays=?"; params.append(sel_pays)
        if sel_etape != "— Toutes —":
            q += " AND etape=?"; params.append(sel_etape)
        if sel_source:
            q += " AND source LIKE ?"; params.append(f"%{sel_source}%")
        q += " ORDER BY pays, nom, contact_nom"
        tous_prospects = db.execute(q, params).fetchall()

        if not tous_prospects:
            st.info(f"Aucun prospect trouvé{f' pour **{sel_pays}**' if sel_pays != '— Tous —' else ''}.")
            db.close(); return

        label_filtre = f"**{len(tous_prospects)} contact(s)**"
        if sel_pays != "— Tous —": label_filtre += f" — {sel_pays}"
        st.success(label_filtre)
        st.markdown("---")

        # ── Producteurs à présenter ───────────────────────────────────────────
        st.markdown("#### 2. Producteurs à présenter")
        if producteurs_list:
            prods_col = st.columns(min(4, len(producteurs_list)))
            prods_selec = []
            for i, prod in enumerate(producteurs_list):
                if prods_col[i % len(prods_col)].checkbox(prod, key=f"prod_{i}"):
                    prods_selec.append(prod)
        else:
            st.warning("Aucun producteur enregistré.")
            prods_selec = []

        # ── Paramètres email ──────────────────────────────────────────────────
        st.markdown("#### 3. Paramètres email")
        ep1, ep2, ep3 = st.columns(3)
        camp_langue = ep1.selectbox("Langue", [
            "Anglais","Français","Chinois","Japonais","Coréen","Bahasa Indonesia"
        ], key="camp_lng")
        camp_ton = ep2.selectbox("Ton", [
            "Chaleureux et enthousiaste","Professionnel et direct",
            "Décontracté et amical","Passionné et lyrique",
        ], key="camp_ton")
        camp_relance_j = ep3.number_input("Relance auto (jours)", 1, 30, 10, key="camp_relance")

        st.markdown("---")

        # ── Tableau de sélection ──────────────────────────────────────────────
        st.markdown("#### 4. Sélectionner les destinataires")
        st.caption("💡 Chaque email est envoyé **individuellement** à chaque contact. "
                   "To = destinataire principal, CC = mis en copie si l'entreprise a plusieurs contacts.")

        # ── Boutons Tout sélectionner / Tout décocher ────────────────────────
        col_all, col_none, _ = st.columns([1, 1, 4])
        select_all  = col_all.button("✅ Tout sélectionner",  key="btn_all")
        deselect_all = col_none.button("⬜ Tout décocher", key="btn_none")

        # Construire DataFrame — clé unique par filtre
        table_key = f"tbl_{sel_pays}_{sel_etape}_{sel_source}"

        rows = []
        for p in tous_prospects:
            nb_ent = sum(1 for x in tous_prospects if x["nom"] == p["nom"])
            role_auto = "To" if nb_ent == 1 else (p["contact_role_email"] or "To")
            # Nom entreprise : masquer si c'est un domaine email générique
            nom_ent = p["nom"] or ""
            nom_lower = nom_ent.lower()
            generiques = ['gmail','yahoo','hotmail','outlook','icloud','me.com',
                          'msn','live.','aol.','qq.com','163.com','proton',
                          'orange.','free.fr','wanadoo','laposte','126.com',
                          'rocketmail','ymail','googlemail']
            if any(g in nom_lower for g in generiques):
                nom_ent = "— (indépendant)"

            rows.append({
                "_id":       p["id"],
                "✓":         True if select_all else (False if deselect_all else False),
                "Pays":      p["pays"] or "—",
                "Entreprise":nom_ent or "— (inconnu)",
                "Contact":   p["contact_nom"] or "—",
                "Poste":     p["contact_poste"] or "—",
                "Email":     p["contact_email"] or "—",
                "Rôle":      role_auto,
                "Étape":     p["etape"] or "—",
                "ℹ️":        "📝" if (p["notes"] and len(p["notes"]) > 10) else "",
            })

        df = pd.DataFrame(rows)

        # ── Tableau éditable ──────────────────────────────────────────────────
        edited = st.data_editor(
            df[["✓","Pays","Entreprise","Contact","Poste","Email","Rôle","Étape","ℹ️"]],
            column_config={
                "✓":          st.column_config.CheckboxColumn("✓", default=False, width="small"),
                "Pays":       st.column_config.TextColumn("Pays", width="small"),
                "Entreprise": st.column_config.TextColumn("Entreprise", width="medium"),
                "Contact":    st.column_config.TextColumn("Contact", width="medium"),
                "Poste":      st.column_config.TextColumn("Poste", width="small"),
                "Email":      st.column_config.TextColumn("Email", width="medium"),
                "Rôle":       st.column_config.SelectboxColumn("Rôle", options=["To","CC"], width="small"),
                "Étape":      st.column_config.TextColumn("Étape", width="small"),
                "ℹ️":         st.column_config.TextColumn("ℹ️", width="small"),
            },
            use_container_width=True,
            hide_index=True,
            key=table_key,
            num_rows="fixed",
        )

        # ── Récupérer sélections ──────────────────────────────────────────────
        selections = []
        for i in range(len(df)):
            if edited.iloc[i]["✓"]:
                p = tous_prospects[i]
                role = edited.iloc[i]["Rôle"]
                selections.append({"prospect": p, "role": role})

        n_selec = len(selections)
        n_to  = sum(1 for s in selections if s["role"] == "To")
        n_cc  = sum(1 for s in selections if s["role"] == "CC")
        st.caption(f"**{n_selec}/{len(df)} sélectionné(s)** — {n_to} × To · {n_cc} × CC  |  "
                   f"Décochez la case ✓ pour exclure un contact · Changez le Rôle directement dans le tableau")

        # ── Suppression de contacts ───────────────────────────────────────────
        with st.expander("🗑️ Supprimer un contact de la liste de prospects"):
            st.caption("Utilisez ceci pour retirer un contact qui a quitté son poste ou son pays.")
            ids_affichés = [p["id"] for p in tous_prospects]
            noms_affichés = [f"{p['contact_nom'] or '—'} — {p['nom']} ({p['pays'] or '—'})"
                             for p in tous_prospects]
            if ids_affichés:
                idx_del = st.selectbox("Contact à supprimer", range(len(noms_affichés)),
                                       format_func=lambda i: noms_affichés[i],
                                       key="del_contact_sel")
                col_a, col_b = st.columns(2)
                raison_del = col_a.selectbox("Raison", [
                    "A quitté son poste", "A quitté le pays",
                    "Email invalide", "Société fermée", "Autre"
                ], key="del_raison")
                if col_b.button("🗑️ Supprimer définitivement", type="primary", key="btn_del"):
                    db.execute("DELETE FROM prospection WHERE id=?", (ids_affichés[idx_del],))
                    db.commit()
                    st.success(f"✅ Contact supprimé ({raison_del}).")
                    st.rerun()

        st.markdown("---")

        # ── Fiche info prospects avec notes ──────────────────────────────────
        avec_notes = [p for p in tous_prospects
                      if p["notes"] and len(p["notes"]) > 10]
        if avec_notes:
            with st.expander(f"ℹ️ Fiches entreprises ({len(avec_notes)} avec notes)"):
                for p in avec_notes:
                    st.markdown(f"**{p['nom']}** — {p['pays'] or '—'}")
                    st.markdown(f"_{p['notes'][:400]}_")
                    if p["concurrents"]:
                        st.markdown(f"🏷️ Concurrents : {p['concurrents']}")
                    st.divider()

        # ── Alerte distribution ───────────────────────────────────────────────
        if sel_pays != "— Tous —":
            try:
                distrib_rows = db.execute("""
                    SELECT producteur_nom, marque_nom, client_actuel
                    FROM distribution
                    WHERE pays=? AND statut='Distribué sous votre suivi'
                    AND (archived=0 OR archived IS NULL)
                    AND client_actuel IS NOT NULL AND client_actuel!=''
                    ORDER BY producteur_nom
                """, (sel_pays,)).fetchall()
                if distrib_rows:
                    # Regrouper par PRODUCTEUR (pas par marque)
                    par_prod = {}
                    for d in distrib_rows:
                        prod = d["producteur_nom"] or "—"
                        client = d["client_actuel"] or "—"
                        marque = d["marque_nom"] or ""
                        if prod not in par_prod:
                            par_prod[prod] = {"client": client, "marques": []}
                        if marque:
                            par_prod[prod]["marques"].append(marque)
                    nb_prods = len(par_prod)
                    with st.expander(f"⚠️ {nb_prods} producteur(s) Angels' Share déjà présent(s) en {sel_pays}"):
                        st.caption("Vérifiez que vous ne contactez pas leurs distributeurs actuels :")
                        for prod, info in par_prod.items():
                            marques_str = f" ({', '.join(info['marques'][:3])})" if info["marques"] else ""
                            st.markdown(f"- **{prod}**{marques_str} → distribué par **{info['client']}**")
            except Exception:
                pass

        # ── Email ─────────────────────────────────────────────────────────────
        st.markdown("#### 5. Rédiger l'email")

        st.info("💡 Rédigez votre email ci-dessous. Chaque email sera envoyé individuellement depuis Outlook — vous ajoutez votre signature manuellement.")

        sujet_edit = st.text_input("📌 Sujet",
            value=st.session_state.get("email_sujet",""), key="sujet_edit")
        corps_edit = st.text_area("✉️ Corps",
            value=st.session_state.get("email_corps",""),
            height=250, key="corps_edit")
        st.caption("💡 Pas de signature — vous signez manuellement dans Outlook.")

        st.markdown("---")

        # ── Envoi ─────────────────────────────────────────────────────────────
        st.markdown("#### 6. Préparer l'envoi")
        if st.button(f"📤 Préparer {n_selec} email(s) dans Outlook",
                     use_container_width=True, type="primary",
                     disabled=n_selec == 0 or not corps_edit):

            relance_date = (date.today() + timedelta(days=int(camp_relance_j))).isoformat()
            recap = []

            for sel in selections:
                p = sel["prospect"]
                role = sel["role"]

                # Tracer dans la DB
                db.execute("""UPDATE prospection SET etape='Contacté',
                    date_prochain_contact=?, updated_at=datetime('now') WHERE id=?""",
                    (relance_date, p["id"]))
                db.execute("""INSERT INTO prospection_interactions
                    (prospect_id, type, contenu, notes) VALUES (?,?,?,?)""",
                    (p["id"], "Email",
                     f"Email prospection — {', '.join(prods_selec) if prods_selec else 'portefeuille'}",
                     f"Sujet: {sujet_edit} | Rôle: {role} | Relance: {relance_date}"))

                if p["contact_email"]:
                    recap.append({
                        "Entreprise": p["nom"], "Pays": p["pays"] or "—",
                        "Contact": p["contact_nom"] or "—",
                        "Email": p["contact_email"], "Rôle": role,
                    })

            db.commit()

            st.success(
                f"✅ **{n_selec} prospect(s)** → étape **Contacté** "
                f"· Relance programmée le **{fmt_date(relance_date)}**"
            )

            if recap:
                df_recap = pd.DataFrame(recap)
                st.dataframe(df_recap, use_container_width=True, hide_index=True)

                # Liens mailto séparés par prospect
                st.markdown("**Ouvrir dans Outlook (un par un) :**")
                for r in recap[:20]:
                    mailto = f"mailto:{r['Email']}?subject={sujet_edit}"
                    st.markdown(f"- [{r['Contact']} — {r['Entreprise']}]({mailto})")

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 2 — PIPELINE
    # ══════════════════════════════════════════════════════════════════════════
    with tab2:
        c1, c2, c3 = st.columns(3)
        f_type  = c1.selectbox("Type", ["Tous"] + TYPES_PROSPECT, key="pip_type")
        f_etape = c2.selectbox("Étape", ["Toutes"] + ETAPES, key="pip_etape")
        f_pays  = c3.selectbox("Pays", ["Tous"] + pays_list, key="pip_pays")

        q = "SELECT * FROM prospection WHERE archived=0"
        params = []
        if f_type != "Tous":  q += " AND type=?";  params.append(f_type)
        if f_etape != "Toutes": q += " AND etape=?"; params.append(f_etape)
        if f_pays != "Tous":  q += " AND pays=?";  params.append(f_pays)
        q += """ ORDER BY CASE etape
            WHEN 'Négociation' THEN 0 WHEN 'Proposition envoyée' THEN 1
            WHEN 'Réunion planifiée' THEN 2 WHEN 'Intéressé' THEN 3
            WHEN 'Contacté' THEN 4 WHEN 'Nouveau prospect' THEN 5
            WHEN 'Recontacter plus tard' THEN 6 ELSE 7 END, nom"""
        prospects_pip = db.execute(q, params).fetchall()

        st.caption(f"{len(prospects_pip)} prospect(s)")

        for p in prospects_pip:
            icon, bg, fg = ETAPE_STYLE.get(p["etape"], ("⚪","#FFF","#000"))
            recontact = ""
            if p["date_prochain_contact"]:
                dc = p["date_prochain_contact"]
                flag = " 🔴" if dc < date.today().isoformat() else ""
                recontact = f" · 📅 {fmt_date(dc)}{flag}"

            with st.expander(
                f'{icon} **{p["nom"]}** — {p["pays"] or "—"} · '
                f'{p["contact_nom"] or "—"} · {p["etape"]}{recontact}'
            ):
                d1, d2, d3 = st.columns(3)
                d1.markdown(f"**Poste :** {p['contact_poste'] or '—'}")
                d2.markdown(f"**Email :** {p['contact_email'] or '—'}")
                d3.markdown(f"**Mobile :** {p['contact_mobile'] or '—'}")
                if p["notes"]: st.info(p["notes"][:300])
                if p["concurrents"]: st.caption(f"🏷️ {p['concurrents']}")

                inters = db.execute(
                    "SELECT * FROM prospection_interactions WHERE prospect_id=? ORDER BY date_interaction DESC",
                    (p["id"],)).fetchall()
                if inters:
                    st.markdown("**📋 Historique**")
                    for i in inters:
                        st.markdown(
                            f"- `{fmt_date(str(i['date_interaction'])[:10])}` "
                            f"**{i['type']}** — {i['contenu']}")

                st.divider()
                with st.form(f"pip_{p['id']}"):
                    fe1, fe2 = st.columns(2)
                    new_etape = fe1.selectbox("Étape", ETAPES,
                        index=ETAPES.index(p["etape"]) if p["etape"] in ETAPES else 0,
                        key=f"pe_{p['id']}")
                    new_rc = fe2.date_input("Prochain contact", value=None, key=f"rc_{p['id']}")
                    fi1, fi2 = st.columns(2)
                    int_type = fi1.selectbox("Interaction", [
                        "Email","Appel","WhatsApp","WeChat","Réunion",
                        "Dégustation","Salon","Réponse reçue","Autre"
                    ], key=f"it_{p['id']}")
                    int_cont = fi2.text_input("Résumé", key=f"ic_{p['id']}")
                    new_notes = st.text_input("Notes", value=p["notes"] or "", key=f"nn_{p['id']}")
                    raison = ""
                    if new_etape == "Refusé":
                        raison = st.text_input("Raison du refus", key=f"ref_{p['id']}")

                    s1, s2 = st.columns(2)
                    if s1.form_submit_button("💾 Mettre à jour", use_container_width=True):
                        rc_str = new_rc.strftime("%Y-%m-%d") if new_rc else None
                        db.execute("""UPDATE prospection SET etape=?, notes=?,
                            date_prochain_contact=?, raison_refus=?,
                            updated_at=datetime('now') WHERE id=?""",
                            (new_etape, new_notes, rc_str, raison, p["id"]))
                        if int_cont:
                            db.execute("""INSERT INTO prospection_interactions
                                (prospect_id, type, contenu) VALUES (?,?,?)""",
                                (p["id"], int_type, int_cont))
                        db.commit(); st.success("✅ Mis à jour."); st.rerun()
                    if s2.form_submit_button("🗑️ Archiver", use_container_width=True):
                        db.execute("UPDATE prospection SET archived=1 WHERE id=?", (p["id"],))
                        db.commit(); st.rerun()

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 3 — NOUVEAU PROSPECT
    # ══════════════════════════════════════════════════════════════════════════
    with tab3:
        with st.form("form_nouveau_prospect", clear_on_submit=True):
            st.markdown("**Identité**")
            n0,n1,n2,n3,n4 = st.columns(5)
            p_civ    = n0.selectbox("Civilité", ["—","M.","Mme","Dr"])
            p_prenom = n1.text_input("Prénom")
            p_nom    = n2.text_input("Société / Nom *")
            p_type   = n3.selectbox("Type", TYPES_PROSPECT)
            p_pays   = n4.selectbox("Pays", [""] + pays_list)
            n5,n6,n7 = st.columns(3)
            p_act    = n5.text_input("Activité")
            p_source = n6.text_input("Source")
            p_prod   = n7.selectbox("Producteur d'intérêt", [""] + producteurs_list)
            st.markdown("**Contact**")
            c1,c2,c3,c4 = st.columns(4)
            p_cnom   = c1.text_input("Nom contact")
            p_cemail = c2.text_input("Email")
            p_cmob   = c3.text_input("Mobile")
            p_cposte = c4.text_input("Poste")
            st.markdown("**Suivi**")
            s1,s2 = st.columns(2)
            p_etape = s1.selectbox("Étape", ETAPES)
            p_rc    = s2.date_input("Prochain contact", value=None)
            p_notes = st.text_area("Notes", height=80)
            if st.form_submit_button("💾 Créer", use_container_width=True):
                if not p_nom:
                    st.error("Le nom est obligatoire.")
                else:
                    rc_str = p_rc.strftime("%Y-%m-%d") if p_rc else None
                    db.execute("""INSERT INTO prospection
                        (civilite,prenom,nom,type,pays,activite,source,etape,
                         contact_nom,contact_email,contact_mobile,contact_poste,
                         producteur_interet,date_prochain_contact,notes)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (p_civ,p_prenom,p_nom,p_type,p_pays,p_act,p_source,
                         p_etape,p_cnom,p_cemail,p_cmob,p_cposte,
                         p_prod,rc_str,p_notes))
                    db.commit()
                    st.success(f"✅ **{p_nom}** créé.")
                    st.rerun()

    # ══════════════════════════════════════════════════════════════════════════
    # TAB 4 — STATISTIQUES
    # ══════════════════════════════════════════════════════════════════════════
    with tab4:
        all_p = db.execute("SELECT * FROM prospection WHERE archived=0").fetchall()
        by_etape = {e:0 for e in ETAPES}
        for p in all_p: by_etape[p["etape"]] = by_etape.get(p["etape"],0)+1

        if by_etape:
            df_e = pd.DataFrame([{"Étape":e,"Nombre":n} for e,n in by_etape.items()])
            st.bar_chart(df_e.set_index("Étape"))

        m1,m2,m3,m4 = st.columns(4)
        m1.metric("Total",len(all_p))
        m2.metric("En cours", sum(1 for p in all_p if p["etape"] not in ("Converti","Refusé","Recontacter plus tard")))
        m3.metric("Convertis", sum(1 for p in all_p if p["etape"]=="Converti"))
        m4.metric("Refusés", sum(1 for p in all_p if p["etape"]=="Refusé"))

        en_retard = [p for p in all_p if p["date_prochain_contact"]
                     and p["date_prochain_contact"] < date.today().isoformat()
                     and p["etape"] not in ("Converti","Refusé")]
        if en_retard:
            st.markdown(f"#### 🔴 {len(en_retard)} relance(s) en retard")
            for p in en_retard:
                st.markdown(f"- **{p['nom']}** ({p['pays'] or '—'}) · {fmt_date(p['date_prochain_contact'])}")

        dans_7j = [p for p in all_p if p["date_prochain_contact"]
                   and date.today().isoformat() <= p["date_prochain_contact"]
                   <= (date.today()+timedelta(days=7)).isoformat()]
        if dans_7j:
            st.markdown(f"#### 🟡 {len(dans_7j)} relance(s) dans 7 jours")
            for p in dans_7j:
                st.markdown(f"- **{p['nom']}** · {fmt_date(p['date_prochain_contact'])}")

    db.close()
