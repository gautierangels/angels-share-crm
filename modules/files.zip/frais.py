import streamlit as st
import pandas as pd
import base64
import os
from pathlib import Path
from database import get_db
from utils import fmt_date, fmt_money, DEVISES
from datetime import date

# ── Chemins justificatifs ─────────────────────────────────────────────────────
RECEIPTS_DIR = Path("/Users/gautiersalinier/Documents/Angels Share Marketing Limited/Angels' Share Management/Justificatifs")
RECEIPTS_DIR.mkdir(parents=True, exist_ok=True)

# ── Moyens de paiement avec catégorie comptable ───────────────────────────────
MOYENS = {
    # Avances de frais (vous payez de votre poche)
    "Liquide":               "avance",
    "QR Bangkok Bank":       "avance",
    "QR Kasikorn":           "avance",
    "Carte Kasikorn":        "avance",
    "Carte Krungsri":        "avance",
    "Carte Crédit Agricole": "avance",
    # Dépenses directes entreprise
    "Carte AirWallex":                    "directe",
    "Virement Airwallex (tiers)":         "directe",
    # Remboursements de frais
    "Virement Airwallex → Kasikorn":      "remboursement",
    "Virement Airwallex → Bangkok Bank":  "remboursement",
    "Virement Airwallex → Crédit Agricole": "remboursement",
}

CATEGORIES_FRAIS = [
    "Voyage", "Hébergement", "Restaurant", "Salon / foire",
    "Logistique", "Abonnement logiciel", "Comptabilité / audit",
    "Assurance", "Work permit", "Représentation", "Autre",
]

CAT_INFO = {
    "avance":        ("💼", "Avance de frais",          "#FFF8F0", "#E67E22"),
    "directe":       ("🏢", "Dépense directe entreprise","#F0F4FF", "#2E86DE"),
    "remboursement": ("💸", "Remboursement de frais",    "#F0FFF4", "#27AE60"),
}


def get_cat_comptable(moyen: str) -> str:
    return MOYENS.get(moyen, "directe")


def save_receipt(frais_id: int, uploaded_file) -> str:
    """Sauvegarde le justificatif et retourne le nom du fichier."""
    ext = Path(uploaded_file.name).suffix.lower()
    filename = f"frais_{frais_id}{ext}"
    path = RECEIPTS_DIR / filename
    with open(path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    return filename


def render():
    st.markdown("## 🧾 Frais")
    db = get_db()

    # Ajouter colonnes manquantes
    for col in ["ALTER TABLE frais ADD COLUMN justificatif TEXT",
                "ALTER TABLE frais ADD COLUMN cat_comptable TEXT"]:
        try: db.execute(col); db.commit()
        except Exception: pass

    # Migrer les frais existants dont cat_comptable est NULL
    frais_null = db.execute(
        "SELECT id, moyen_paiement FROM frais WHERE cat_comptable IS NULL OR cat_comptable = ''"
    ).fetchall()
    if frais_null:
        for f in frais_null:
            cat = get_cat_comptable(f["moyen_paiement"] or "")
            db.execute("UPDATE frais SET cat_comptable=? WHERE id=?", (cat, f["id"]))
        db.commit()

    tab1, tab2, tab3 = st.tabs(["📋 Mes frais", "➕ Nouveau frais", "📊 Récapitulatif comptable"])

    # ══ LISTE DES FRAIS ═══════════════════════════════════════════════════════
    with tab1:
        c1, c2, c3, c4 = st.columns(4)
        f_cat    = c1.selectbox("Catégorie", ["Toutes"] + CATEGORIES_FRAIS)
        f_type   = c2.selectbox("Type comptable", ["Tous", "Avance de frais",
                                                    "Dépense directe entreprise",
                                                    "Remboursement de frais"])
        f_mois   = c3.text_input("Mois (YYYY-MM)", placeholder="2026-05")
        f_search = c4.text_input("Recherche", placeholder="Description…")

        q = "SELECT * FROM frais WHERE 1=1"
        params = []
        if f_cat != "Toutes":
            q += " AND categorie=?"; params.append(f_cat)
        if f_mois:
            q += " AND date_frais LIKE ?"; params.append(f"{f_mois}%")
        if f_search:
            q += " AND description LIKE ?"; params.append(f"%{f_search}%")

        type_map = {
            "Avance de frais":           "avance",
            "Dépense directe entreprise":"directe",
            "Remboursement de frais":    "remboursement",
        }
        if f_type != "Tous":
            q += " AND cat_comptable=?"; params.append(type_map[f_type])

        q += " ORDER BY date_frais DESC"
        frais_list = db.execute(q, params).fetchall()

        if not frais_list:
            st.info("Aucun frais enregistré.")
        else:
            total_avance  = sum(f["montant"] or 0 for f in frais_list if f["cat_comptable"] == "avance")
            total_directe = sum(f["montant"] or 0 for f in frais_list if f["cat_comptable"] == "directe")
            total_rembours= sum(f["montant"] or 0 for f in frais_list if f["cat_comptable"] == "remboursement")

            m1, m2, m3 = st.columns(3)
            m1.metric("💼 Avances de frais",           fmt_money(total_avance),
                      help="À rembourser par l'entreprise")
            m2.metric("🏢 Dépenses directes entreprise", fmt_money(total_directe))
            m3.metric("💸 Remboursements reçus",        fmt_money(total_rembours))

            solde = total_avance - total_rembours
            if solde > 0:
                st.warning(f"💼 Solde avances non remboursées : **{fmt_money(solde)}** — vous êtes créditeur envers l'entreprise.")
            elif solde < 0:
                st.info(f"✅ Solde : {fmt_money(abs(solde))} — vous avez été remboursé au-delà de vos avances.")
            else:
                st.success("✅ Avances de frais entièrement remboursées.")

            st.markdown("---")

            for f in frais_list:
                cat_c = f["cat_comptable"] if f["cat_comptable"] else get_cat_comptable(f["moyen_paiement"] or "")
                icon, label, bg, border = CAT_INFO.get(cat_c, ("📄", cat_c, "#F8F8F8", "#CCC"))

                with st.expander(
                    f'{icon} {fmt_date(f["date_frais"])} — **{f["description"]}** '
                    f'| {fmt_money(f["montant"], f["devise"])} '
                    f'| {label}'
                    + (" 📎" if f["justificatif"] else "")
                ):
                    # Infos
                    c1, c2, c3 = st.columns(3)
                    c1.markdown(f"**Catégorie :** {f['categorie'] or '—'}")
                    c2.markdown(f"**Paiement :** {f['moyen_paiement'] or '—'}")
                    c3.markdown(f"**Type :** {icon} {label}")
                    if f["notes"]:
                        st.caption(f["notes"])

                    # Justificatif existant
                    if f["justificatif"]:
                        receipt_path = RECEIPTS_DIR / f["justificatif"]
                        if receipt_path.exists():
                            ext = receipt_path.suffix.lower()
                            if ext in (".jpg", ".jpeg", ".png", ".webp", ".heic"):
                                st.image(str(receipt_path), width=400)
                            else:
                                with open(receipt_path, "rb") as fp:
                                    st.download_button(
                                        f"⬇️ Télécharger {f['justificatif']}",
                                        data=fp.read(),
                                        file_name=f["justificatif"],
                                        key=f"dl_{f['id']}"
                                    )
                        st.caption(f"📎 {f['justificatif']}")

                    # Upload justificatif — toujours visible
                    st.markdown("**📎 Justificatif :**")
                    uploaded = st.file_uploader(
                        "Photo, PDF, Excel… (glissez ou cliquez)",
                        type=["jpg","jpeg","png","webp","heic","pdf","xlsx","xls","csv"],
                        key=f"upload_{f['id']}",
                        label_visibility="collapsed"
                    )
                    if uploaded:
                        filename = save_receipt(f["id"], uploaded)
                        cat_c_val = get_cat_comptable(f["moyen_paiement"] or "")
                        db.execute(
                            "UPDATE frais SET justificatif=?, cat_comptable=? WHERE id=?",
                            (filename, cat_c_val, f["id"])
                        )
                        db.commit()
                        st.success(f"✅ **{uploaded.name}** enregistré.")
                        st.rerun()

                    # Supprimer
                    if st.button("🗑️ Supprimer ce frais", key=f"del_{f['id']}"):
                        if f["justificatif"]:
                            p = RECEIPTS_DIR / f["justificatif"]
                            if p.exists(): p.unlink()
                        db.execute("DELETE FROM frais WHERE id=?", (f["id"],))
                        db.commit()
                        st.rerun()

    # ══ NOUVEAU FRAIS ═════════════════════════════════════════════════════════
    with tab2:
        with st.form("form_frais", clear_on_submit=True):
            f1, f2 = st.columns(2)
            f_date = f1.date_input("Date *", value=date.today())
            f_desc = f2.text_input("Description *", placeholder="Ex: Billet Bangkok–HKG Vinexpo")

            f3, f4, f5, f6 = st.columns(4)
            f_cat_v   = f3.selectbox("Catégorie", CATEGORIES_FRAIS)
            f_moyen_v = f4.selectbox("Moyen de paiement", list(MOYENS.keys()))
            f_mt      = f5.number_input("Montant *", min_value=0.0, step=1.0, format="%.2f")
            f_dev     = f6.selectbox("Devise", DEVISES)

            # Aperçu catégorie comptable
            cat_preview = get_cat_comptable(f_moyen_v)
            icon_p, label_p, bg_p, border_p = CAT_INFO[cat_preview]
            st.markdown(
                f'<div style="background:{bg_p};border-left:3px solid {border_p};'
                f'padding:6px 12px;border-radius:6px;font-size:0.9rem;">'
                f'{icon_p} Catégorie comptable : <b>{label_p}</b></div>',
                unsafe_allow_html=True
            )

            f_notes = st.text_area("Notes", height=60)

            submitted = st.form_submit_button("💾 Enregistrer", use_container_width=True)
            if submitted:
                if not f_desc or f_mt <= 0:
                    st.error("Description et montant sont obligatoires.")
                else:
                    cat_c = get_cat_comptable(f_moyen_v)
                    db.execute(
                        "INSERT INTO frais (date_frais,description,categorie,moyen_paiement,montant,devise,notes,cat_comptable) VALUES (?,?,?,?,?,?,?,?)",
                        (f_date.strftime("%Y-%m-%d"), f_desc, f_cat_v, f_moyen_v, f_mt, f_dev, f_notes, cat_c)
                    )
                    db.commit()
                    st.success(f"✅ Frais enregistré — {icon_p} {label_p}")
                    st.rerun()

    # ══ RÉCAPITULATIF COMPTABLE ═══════════════════════════════════════════════
    with tab3:
        st.markdown("#### Récapitulatif par type comptable")
        all_frais = db.execute("SELECT * FROM frais ORDER BY date_frais DESC").fetchall()

        if not all_frais:
            st.info("Aucun frais enregistré.")
        else:
            # Totaux globaux
            avances    = [f for f in all_frais if f["cat_comptable"] == "avance"]
            directes   = [f for f in all_frais if f["cat_comptable"] == "directe"]
            rembours   = [f for f in all_frais if f["cat_comptable"] == "remboursement"]

            ta = sum(f["montant"] or 0 for f in avances)
            td = sum(f["montant"] or 0 for f in directes)
            tr = sum(f["montant"] or 0 for f in rembours)
            solde = ta - tr

            st.markdown(f"""
| Type | Nombre | Total |
|---|---|---|
| 💼 Avances de frais | {len(avances)} | **{fmt_money(ta)}** |
| 🏢 Dépenses directes entreprise | {len(directes)} | **{fmt_money(td)}** |
| 💸 Remboursements reçus | {len(rembours)} | **{fmt_money(tr)}** |
| **Solde à rembourser** | | **{fmt_money(solde)}** |
            """)

            if solde > 0:
                st.warning(f"⚠️ L'entreprise vous doit **{fmt_money(solde)}** de remboursement.")
            elif solde == 0:
                st.success("✅ Comptes équilibrés.")

            st.markdown("---")
            st.markdown("#### Répartition par catégorie de dépense")
            by_cat = {}
            for f in all_frais:
                if f["cat_comptable"] in ("avance", "directe"):
                    k = f["categorie"] or "Autre"
                    by_cat[k] = by_cat.get(k, 0) + (f["montant"] or 0)
            if by_cat:
                df_cat = pd.DataFrame(
                    sorted(by_cat.items(), key=lambda x: -x[1]),
                    columns=["Catégorie", "Total (EUR)"]
                )
                st.bar_chart(df_cat.set_index("Catégorie"))

            st.markdown("#### Répartition par moyen de paiement")
            by_moyen = {}
            for f in all_frais:
                k = f["moyen_paiement"] or "Non renseigné"
                by_moyen[k] = by_moyen.get(k, 0) + (f["montant"] or 0)
            if by_moyen:
                df_m = pd.DataFrame(
                    sorted(by_moyen.items(), key=lambda x: -x[1]),
                    columns=["Moyen de paiement", "Total"]
                )
                st.dataframe(df_m, use_container_width=True, hide_index=True)

    db.close()
